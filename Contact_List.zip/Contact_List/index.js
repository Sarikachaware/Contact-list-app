const express = require('express');
const port = 8000;
const path = require('path');

const app = express();
//var bodyParser = require('body-parser');
//app.use(bodyParser.urlencoded({ extended: false }))


app.use(express.urlencoded());


app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views'));


var contactList = [
     {
        name:"Arpan",
        phone:"1111111"
    },

    {
            name:"arika",
            phone:"000000000"
    },
    {
        name:"sachin",
        phone :"2232323"
    }
]


app.get('/',function(req,res)
{
    return res.render('home',
    {
        title:"contactList",
        contact_list:contactList
    });
    
});



app.get('/practice',function(req,res)
{
    return res.render('practice',
    {
        title:"let us play with ejs",

    });
});

app.post('/create_contact',function(req,res)
{
   // return res.render('/practice');
   contactList.push(
    {
        name:req.body.name,
        phone:req.body.phone

    });
   return res.redirect('/');

}
);


app.listen(port,function(err){
    if(err)
    {
        console.log('error in running thr server',err);
    }

    console.log('My express server is running on port',port);

})